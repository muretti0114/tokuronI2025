INITDBDIR for your MySQL
Place your .sql .sh .sql.gz files for initialization
