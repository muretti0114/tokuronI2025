CONFDIR of your MySQL
Place you .cnf file for customized settings