Place your app.war in this directory.
